﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PR4_4.Classes;

namespace PR4_4.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPagq.xaml
    /// </summary>
    public partial class AddEditPagq : Page
    {
        private Sportsmans _currentsportmans = new Sportsmans();
        public AddEditPagq(Sportsmans selectedUser)
        {
            InitializeComponent();
            if (selectedUser != null)
                _currentsportmans = selectedUser;
            DataContext = _currentsportmans;
        }
        private void Savebtn_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();// Объект для сообщение об ошибке
            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentsportmans.LastNameSportsman))
                error.AppendLine("Укажите фамилию");
            if (string.IsNullOrWhiteSpace(Date.Text))
                error.AppendLine("Укажите дату рождения");
            if (string.IsNullOrWhiteSpace(_currentsportmans.Сountry))
                error.AppendLine("Укажите строну");
            if (string.IsNullOrWhiteSpace(kodsportscategory.Text))
                error.AppendLine("Укажите код категории");
            if (error.Length > 0)

            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentsportmans.KodSportsman == 0)
                chessEntities.GetContext().Sportsmans.Add(_currentsportmans);//Добавить в контекст
            try
            {

                chessEntities.GetContext().SaveChanges();// Сохранить изменения
                MessageBox.Show("Данные сохраненны");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
